# P1 - Sistema de Controle de Cinema

Projeto acadêmico feito com HTML, Bootstrap 5.3.3 e JavaScript puro.
O código está separado por página e usa funções simples, arrays e objetos.

## Como executar

1. Extraia o ZIP inteiro, mantendo as pastas `css` e `js`.
2. Abra a pasta no Visual Studio Code e use a extensão Live Server para abrir `index.html`.
3. Alternativa, se tiver Python instalado: abra o terminal nesta pasta, execute `python -m http.server 8000` e acesse http://localhost:8000.

Use sempre o mesmo navegador e endereço. Prefira um servidor local: abrir os HTMLs diretamente com duplo clique pode separar o localStorage de cada página, dependendo do navegador.
Não é preciso instalar pacotes do projeto. O Bootstrap está incluído na pasta css e não depende de internet.

## Ordem para testar

1. Em Filmes, cadastre um filme com todos os campos.
2. Em Salas, cadastre uma sala (por exemplo, Sala 1, capacidade 2, tipo 2D).
3. Em Cadastrar sessão, selecione o filme e a sala, um horário futuro, preço, idioma e formato.
4. Abra Sessões disponíveis e clique em Comprar ingresso.
5. Confira que a sessão já está selecionada. Preencha cliente, CPF de teste com 11 dígitos, assento A1 e pagamento.
6. Confirme a venda. Tente vender A1 novamente: o sistema impede a repetição.
7. Venda A2: ao atingir a capacidade 2, a sessão deixa de aparecer como disponível.
8. Recarregue as páginas para verificar que os dados continuam salvos.

## Arquivos e requisitos

- index.html: menu inicial com acesso às cinco funcionalidades.
- cadastro-filmes.html e js/filmes.js: título, gênero, descrição, classificação, duração e estreia; chave `filmes`.
- cadastro-salas.html e js/salas.js: nome, capacidade e tipo; chave `salas`.
- cadastro-sessoes.html e js/cadastro-sessoes.js: filme e sala carregados dinamicamente, data/hora, preço, idioma e formato; chave `sessoes`.
- venda-ingressos.html e js/ingressos.js: sessão, cliente, CPF, assento e pagamento; chave `ingressos`.
- sessoes.html e js/sessoes.js: título do filme, nome da sala, data/hora, preço e botão Comprar ingresso com ID na URL.
- js/comum.js: leitura e gravação, mensagens e funções compartilhadas.
- css/estilo.css: pequenos ajustes visuais.
- css/bootstrap.min.css: biblioteca Bootstrap, distribuída sob licença MIT (aviso no próprio arquivo).

Todas as páginas têm o mesmo menu no topo, que permanece visível ao rolar.

## Como o JavaScript funciona

`lerDados` lê uma chave e converte JSON em array. Se a chave ainda não existe, retorna um array vazio.
Ao enviar um formulário, `preventDefault` evita o recarregamento. Criamos um objeto, adicionamos com `push` e gravamos com `JSON.stringify` e `localStorage.setItem`.
Os IDs conectam sessão, filme e sala. `find` encontra um registro; `filter` seleciona sessões disponíveis. `createElement` cria opções e linhas, e `textContent` insere o texto cadastrado com segurança.
`URLSearchParams` lê o ID enviado pelo botão Comprar ingresso.

## Limites da simulação

Os dados ficam apenas no navegador e endereço usados. Não há login, servidor de dados, sincronização ou pagamento real. Limpar os dados do navegador apaga os cadastros.
Use dados fictícios nos testes. O CPF tem validação de formato (11 dígitos), sem cálculo dos dígitos verificadores. Nenhum dado de cartão é solicitado.
Assentos são identificadores de texto (A1, A10 etc.), sem mapa físico. O sistema verifica repetição e capacidade total. Não verifica conflito de horários entre sessões.
Sessões passadas e lotadas não aparecem como disponíveis.
